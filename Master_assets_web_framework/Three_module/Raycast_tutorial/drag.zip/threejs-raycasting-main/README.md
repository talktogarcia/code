# threejs-raycasting

Example for three.js raycaster to build mouse picking, drag & drop of 3D objects ...

![Screenshot](https://github.com/tamani-coding/threejs-raycasting/blob/main/screenshot.png?raw=true)

Run `npm install` then `npm run start`.